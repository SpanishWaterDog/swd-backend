"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForbiddenException = void 0;
const ApplicationException_1 = require("./ApplicationException");
class ForbiddenException extends ApplicationException_1.ApplicationException {
    constructor(message = 'User has no access to resource') {
        super();
        this.message = message;
    }
}
exports.ForbiddenException = ForbiddenException;
