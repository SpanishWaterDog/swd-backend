"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotFoundException = void 0;
const ApplicationException_1 = require("./ApplicationException");
class NotFoundException extends ApplicationException_1.ApplicationException {
    constructor(message = 'Resource not found or you have no access to it') {
        super();
        this.message = message;
    }
}
exports.NotFoundException = NotFoundException;
