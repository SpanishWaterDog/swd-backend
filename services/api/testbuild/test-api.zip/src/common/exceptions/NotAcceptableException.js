"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotAcceptableException = void 0;
const ApplicationException_1 = require("./ApplicationException");
class NotAcceptableException extends ApplicationException_1.ApplicationException {
    constructor(message = 'User has sent request that cannot be processed') {
        super();
        this.message = message;
    }
}
exports.NotAcceptableException = NotAcceptableException;
