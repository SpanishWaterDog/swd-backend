"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConflictException = void 0;
const ApplicationException_1 = require("./ApplicationException");
class ConflictException extends ApplicationException_1.ApplicationException {
    constructor(message = 'Resource already exists') {
        super();
        this.message = message;
    }
}
exports.ConflictException = ConflictException;
