"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceUnavailableException = void 0;
const ApplicationException_1 = require("./ApplicationException");
class ServiceUnavailableException extends ApplicationException_1.ApplicationException {
    constructor(message = 'Service Unavailable') {
        super();
        this.message = message;
    }
}
exports.ServiceUnavailableException = ServiceUnavailableException;
