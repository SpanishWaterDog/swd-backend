"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// import Config from '@common/Config';
const response_1 = require("./response");
const ApplicationException_1 = require("../exceptions/ApplicationException");
const BadRequestException_1 = require("../exceptions/BadRequestException");
const ConflictException_1 = require("../exceptions/ConflictException");
const ForbiddenException_1 = require("../exceptions/ForbiddenException");
const NotAcceptableException_1 = require("../exceptions/NotAcceptableException");
const NotFoundException_1 = require("../exceptions/NotFoundException");
const ServiceUnavailableException_1 = require("../exceptions/ServiceUnavailableException");
const EventData_1 = __importDefault(require("./EventData"));
const clone = (body) => JSON.parse(JSON.stringify(body ?? {}));
const api = function (handler) {
    return async function (event, context) {
        event.data = new EventData_1.default(event);
        // Remove sensitive data
        const headers = clone(event.headers);
        delete headers.authorization;
        delete headers.Authorization;
        delete headers['x-amz-security-token'];
        const multiValueHeaders = clone(event.multiValueHeaders);
        delete multiValueHeaders.authorization;
        delete multiValueHeaders.Authorization;
        delete multiValueHeaders['x-amz-security-token'];
        const requestContext = clone(event.requestContext);
        delete requestContext.authorizer?.claims.email;
        // const { httpMethod, path, pathParameters, multiValueQueryStringParameters, queryStringParameters, resource, body } = event;
        // const loggedData = {
        //   httpMethod,
        //   path,
        //   pathParameters,
        //   multiValueQueryStringParameters,
        //   queryStringParameters,
        //   requestContext,
        //   resource,
        //   headers,
        //   multiValueHeaders,
        //   body: body ? '*****' : '',
        // };
        //
        // if (Config.getEnvKey() === 'exp' || Config.getEnvKey() === 'dev') {
        //   loggedData.body = body ?? '';
        // }
        // Logger.setContext('request', loggedData);
        // Logger.debug('EndpointInvoked', 'Endpoint invoked');
        try {
            return await handler(event, context);
        }
        catch (error) {
            if (error instanceof NotFoundException_1.NotFoundException) {
                return (0, response_1.errorResponse)(404, error.message);
            }
            else if (error instanceof ForbiddenException_1.ForbiddenException) {
                return (0, response_1.errorResponse)(403, error.message);
            }
            else if (error instanceof ServiceUnavailableException_1.ServiceUnavailableException) {
                return (0, response_1.errorResponse)(503, error.message);
            }
            else if (error instanceof ConflictException_1.ConflictException) {
                return (0, response_1.errorResponse)(409, error.message);
            }
            else if (error instanceof NotAcceptableException_1.NotAcceptableException) {
                return (0, response_1.errorResponse)(406, error.message);
            }
            else if (error instanceof BadRequestException_1.BadRequestException || error instanceof ApplicationException_1.ApplicationException) {
                return (0, response_1.errorResponse)(400, error.message);
            }
            return (0, response_1.unhandledErrorResponse)(error);
        }
    };
};
exports.default = api;
