"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unhandledErrorResponse = exports.errorResponse = exports.response = void 0;
const logger_1 = __importDefault(require("@swd/logger"));
function response(code, response, contentType, cacheControlMaxAgeInMinutes, isBase64Encoded) {
    let result = {
        statusCode: code || 200,
        body: response ? JSON.stringify(response) : '',
        headers: {
            ...getCORSAttachment(),
        },
    };
    if (contentType && result.headers) {
        result.headers['Content-Type'] = contentType;
    }
    if (cacheControlMaxAgeInMinutes && result.headers) {
        result.headers['Cache-Control'] = `max-age=${cacheControlMaxAgeInMinutes * 60}`;
    }
    if (isBase64Encoded) {
        result = { ...result, isBase64Encoded: true };
    }
    return result;
}
exports.response = response;
function errorResponse(code, message) {
    logger_1.default.debug('controllerError', message, { code });
    return response(code, { message });
}
exports.errorResponse = errorResponse;
function unhandledErrorResponse(error) {
    logger_1.default.error('unhandledError', 'Unhandled exception', undefined, error);
    return response(500, { message: 'Unknown Error' });
}
exports.unhandledErrorResponse = unhandledErrorResponse;
function getCORSAttachment() {
    return {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
        'Content-Security-Policy': `Include default-src 'self'`,
        'Strict-Transport-Security': 'max-age=300; includeSubDomains; preload',
        'X-Content-Type-Options': `'nosniff'`,
        'X-XSS-Protection': `'1'`,
    };
}
