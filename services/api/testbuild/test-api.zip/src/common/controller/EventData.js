"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = __importDefault(require("lodash"));
class EventData {
    constructor(event) {
        this.event = event;
        this.queryStringParams = event.queryStringParameters || {};
        this.pathParams = event.pathParameters || {};
        this.body = event.body;
        this.headers = event.headers;
    }
    get token() {
        const claims = this.event.requestContext && this.event.requestContext.authorizer && this.event.requestContext.authorizer.claims;
        return {
            userId: claims ? claims['custom:userId'] || '' : '',
            clientId: claims?.aud || '',
        };
    }
    get pagination() {
        return {
            limit: this.queryStringParams.limit ? Number(this.queryStringParams.limit) : undefined,
            skip: this.queryStringParams.skip ? Number(this.queryStringParams.skip) : undefined,
        };
    }
    get search() {
        return this.queryStringParams.search || '';
    }
    get sort() {
        return {
            sort: this.queryStringParams.sort || '',
            sortType: this.queryStringParams.sortType === 'ASC' ? 'ASC' : this.queryStringParams.sortType === 'DESC' ? 'DESC' : undefined,
        };
    }
    getPathParam(name) {
        return (this.pathParams || {})[name] || '';
    }
    getBodyValue(key) {
        const body = JSON.parse(this.body || '{}');
        return key === '$' ? body : body[key];
    }
    getBody() {
        return JSON.parse(this.body || '{}');
    }
    getQueryStringParam(key) {
        return this.queryStringParams[key] === '' || this.queryStringParams[key] === null ? undefined : this.queryStringParams[key];
    }
    getQueryStringParamAsNumber(key) {
        const value = this.queryStringParams[key];
        if (!value) {
            return undefined;
        }
        return +value;
    }
    getQueryStringParamAsStringArray(key) {
        const value = this.queryStringParams[key];
        if (!value) {
            return undefined;
        }
        return value.split(',');
    }
    getQueryStringParamAsDate(key) {
        const value = this.queryStringParams[key];
        if (!value) {
            return undefined;
        }
        const timestamp = Date.parse(value);
        if (!isNaN(timestamp)) {
            return new Date(timestamp);
        }
        return undefined;
    }
    getHeaders(regexFilter) {
        if (!regexFilter) {
            return this.headers;
        }
        return lodash_1.default.pickBy(this.headers, (value, key) => regexFilter.test(key));
    }
    endpointVersion() {
        return this.headers['endpoint-version'] ?? undefined;
    }
}
exports.default = EventData;
