"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.prismaClient = void 0;
const api_1 = __importDefault(require("../../../common/controller/api"));
const action_1 = require("../../application/getExercise/action");
const response_1 = require("../../../common/controller/response");
const client_1 = require("@prisma/client");
exports.prismaClient = new client_1.PrismaClient();
const getExercise = (0, api_1.default)(async (event) => {
    const params = {
        token: event.data.token,
        exerciseId: event.data.getPathParam('id'),
    };
    const exercise = await (0, action_1.getExerciseAction)(params);
    return (0, response_1.response)(200, exercise);
});
exports.default = getExercise;
