"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ExerciseService {
    static async getExerciseById(id, prisma) {
        return await prisma.exercise.findUnique({
            where: {
                id,
            },
        });
    }
}
exports.default = ExerciseService;
