"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getExerciseAction = void 0;
const handler_1 = require("../../controller/getExercise/handler");
const exercise_service_1 = __importDefault(require("../../repository/exercise.service"));
async function getExerciseAction(event) {
    return await exercise_service_1.default.getExerciseById(event.exerciseId, handler_1.prismaClient);
}
exports.getExerciseAction = getExerciseAction;
